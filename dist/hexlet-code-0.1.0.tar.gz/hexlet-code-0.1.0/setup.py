# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': 'Проект #1\n#"Игры разума"\n\n####Hexlet tests and linter status:\n[![Actions Status](https://github.com/alekseychudinov/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/alekseychudinov/python-project-lvl1/actions)    [![Maintainability](https://api.codeclimate.com/v1/badges/a99a88d28ad37a79dbf6/maintainability)](https://codeclimate.com/github/alekseychudinov/python-project-lvl1/maintainability)    [![test-my-project](https://github.com/alekseychudinov/python-project-lvl1/actions/workflows/first_project-check.yml/badge.svg)](https://github.com/alekseychudinov/python-project-lvl1/actions/workflows/first_project-check.yml)\n\n####Описание:\n«Игры разума» — набор из пяти консольных игр, построенных по принципу популярных мобильных приложений для прокачки мозга. Каждая игра задает вопросы, на которые нужно дать правильные ответы. После трех правильных ответов считается, что игра пройдена. Неправильные ответы завершают игру и предлагают пройти ее заново. Игры:\n\n+ Калькулятор. Арифметические выражения, которые необходимо вычислить.\n+ Прогрессия. Поиск пропущенных чисел в последовательности чисел.\n+ Определение четного числа.\n+ Определение наибольшего общего делителя.\n+ Определение простого числа.\n\n####Минимальные требования:\n- процессор двухъядерный Intel Celeron 1,6-1,8GHz;\n- оперативная память 4 Gb и выше;\n- жесткий диск от 80GB (при установке используется около 100 Мбайт)\n- USB-порт (минимум 2 порта).;\n- монитор.\n\nИнструкции по установке и запуску:\nСохраняете папку dist к себе на компьютер.\nИз той же директории набираете команду "make package-install".\nДалее в зависмости от игры нужно набрать соответствующую команду:\n* brain-even - Определение четного числа.\n* brain-calc - Калькулятор. Арифметические выражения, которые необходимо вычислить.\n* brain-gcd - Определение наибольшего общего делителя.\n* brain-progression - Прогрессия. Поиск пропущенных чисел в последовательности чисел.\n* brain-prime - Определение простого числа.\n\n\n####Примеры игр:\n\n+ Определение четного числа:\n[![asciicast](https://asciinema.org/a/461827.png)](https://asciinema.org/a/461827)\n\n+ Калькулятор. Арифметические выражения, которые необходимо вычислить:\n[![asciicast](https://asciinema.org/a/461949.png)](https://asciinema.org/a/461949)\n\n+ Определение наибольшего общего делителя:\n[![asciicast](https://asciinema.org/a/461959.png)](https://asciinema.org/a/461959)\n\n+ Прогрессия. Поиск пропущенных чисел в последовательности чисел:\n[![asciicast](https://asciinema.org/a/461975.png)](https://asciinema.org/a/461975)\n\n+ Определение простого числа:\n[![asciicast](https://asciinema.org/a/461985.png)](https://asciinema.org/a/461985)\n',
    'author': 'AlekseyChudinov',
    'author_email': 'alekseychudinov@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/alekseychudinov/python-project-lvl1',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)

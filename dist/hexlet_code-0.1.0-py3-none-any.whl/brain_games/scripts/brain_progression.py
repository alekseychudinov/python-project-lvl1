#!/usr/bin/env python


from brain_games.logics import logics


def main():
    return logics("progression")


if __name__ == "__main__":
    main()
